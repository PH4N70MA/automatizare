#include <ESP8266WiFi.h>
#include <ESP8266WebServer.h>
#include <EEPROM.h>
#include <PubSubClient.h>

int workTime = 0;
int restTime = 0;
int mode = 0;
int manualToggle = 0;
int sensorThreshold = 0;

#define ADDR_W 0 // Address to store 'w'
#define ADDR_R 1 // Address to store 'r'
#define ADDR_T 2 // Address to store 't'
#define ADDR_M 3 // Address to store 'm'
#define ADDR_S 4 // Address to store 's'


// Wi-Fi credentials
const char* ssid = "MikroLAB";
const char* password = "@2wsxdr%5";

unsigned long lastPingSentTime = 0;
const unsigned long pingInterval = 2990;

// Create a web server object that listens for HTTP request on port 80
ESP8266WebServer server(80);

// Variables to hold sensor data
String temperature = "N/A";
String humidity = "N/A";
String particles = "N/A";

// Function declarations
void handleRoot();
void handleNotFound();
void handleStyles();
void handleScripts();

void handleDataRequest() {
    String workTimeStr = server.arg("workTime");
    String restTimeStr = server.arg("restTime");
    String modeStr = server.arg("mode");
    String manualToggleStr = server.arg("manualToggle");
    String sensorThresholdStr = server.arg("sensorThreshold");

    int w = workTimeStr.toInt();
    int r = restTimeStr.toInt();
    int t = modeStr.toInt();
    int m = manualToggleStr.toInt();
    int s = sensorThresholdStr.toInt();

    // Write values to EEPROM
    EEPROM.begin(512); // Initialize EEPROM
    EEPROM.write(ADDR_W, w);
    EEPROM.write(ADDR_R, r);
    EEPROM.write(ADDR_T, t);
    EEPROM.write(ADDR_M, m);
    EEPROM.write(ADDR_S, s);
    EEPROM.commit(); // Store data to EEPROM
    EEPROM.end();    // Release EEPROM


Serial.print("W");
    Serial.println(w);
    Serial.print("R");
    Serial.println(r);
    Serial.print("T");
    Serial.println(t);
    Serial.print("M");
    Serial.println(m);
    Serial.print("S");
    Serial.println(s);

    // Respond to the client
    server.send(200, "text/plain", "Data sent to Arduino");
}

void setup() {
  // Start the Serial communication to send messages to the computer
  Serial.begin(9600);
  
  // Connect to Wi-Fi network
  WiFi.begin(ssid, password);

  // Wait for connection
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }

  // Print local IP address
  Serial.println("Connected to WiFi");
  Serial.println(WiFi.localIP());


 EEPROM.begin(512); // Initialize EEPROM
    workTime = EEPROM.read(ADDR_W);
    restTime = EEPROM.read(ADDR_R);
    mode = EEPROM.read(ADDR_T);
    manualToggle = EEPROM.read(ADDR_M);
    sensorThreshold = EEPROM.read(ADDR_S);
    EEPROM.end(); // Release EEPROM
    
  // Define routes
  server.on("/", handleRoot);
  server.on("/styles.css", handleStyles);
  server.on("/scripts.js", handleScripts);
  server.onNotFound(handleNotFound);
  server.on("/data", HTTP_POST, handleDataRequest);
  
  // Start server
  server.begin();
  Serial.println("HTTP server started");
}

void loop() {
  // Check for serial input 
  if (Serial.available() > 0) {
    String data = Serial.readStringUntil('\n');
    if (data.startsWith("T:")) {
      temperature = data.substring(2);
    } else if (data.startsWith("H:")) {
      humidity = data.substring(2);
    } else if (data.startsWith("P:")) {
      particles = data.substring(2);
    }
  }
  if (millis() - lastPingSentTime > pingInterval) {
    Serial.println("PING");
    lastPingSentTime = millis();
  } 
  // Handle client requests
  server.handleClient();
}

// Handles root URL (/)
void handleRoot() {
    // Read values from EEPROM
    EEPROM.begin(512); // Initialize EEPROM
    workTime = EEPROM.read(ADDR_W);
    restTime = EEPROM.read(ADDR_R);
    mode = EEPROM.read(ADDR_T);
    manualToggle = EEPROM.read(ADDR_M);
    sensorThreshold = EEPROM.read(ADDR_S);
    EEPROM.end(); // Release EEPROM

    String html = R"(
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Dashboard</title>
            <link rel="stylesheet" href="styles.css">
            <script src="scripts.js"></script>
        </head>
        <body>
            <div class="container">
                <div class="card">
                    <div class="card-header">
                        <span>Temperatura</span>
                    </div>
                    <div class="gauge">
                       <span id="temperature">)" + temperature + R"(</span>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <span>Umiditatea</span>
                    </div>
                    <div class="gauge">
                        <span id="humidity">)" + humidity + R"(%</span>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <span>Microparticule</span>
                    </div>
                    <div class="gauge">
                        <span id="particles">)" + particles + R"(</span>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <span>Timp de lucru</span>
                    </div>
                    <div class="slider-container">
                        <input type="range" min="0" max="30" value=")" + String(workTime) + R"(" id="work-time">
                        <span id="work-time-value">)" + String(workTime) + R"(</span>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <span>Timp de repaus</span>
                    </div>
                    <div class="slider-container">
                        <input type="range" min="20" max="40" value=")" + String(restTime) + R"(" id="rest-time">
                        <span id="rest-time-value">)" + String(restTime) + R"(</span>
                    </div>
                </div>
                <div class="card">
                    <div class="card-header">
                        <span>Regim</span>
                    </div>
                    <div class="dropdown-container">
                        <select id="mode">
                            <option value="select">Select...</option>
                            <option value="1">Auto</option>
                            <option value="2">Manual</option>
                            <option value="3">Sensor</option>
                        </select>
                    </div>
                </div>
                <div class="card" id="manual-mode-card" style="display: none;">
                    <div class="card-header">
                        <span>Control Manual</span>
                    </div>
                    <div class="toggle-container">
                        <label class="switch">
                            <input type="checkbox" id="manual-toggle">
                            <span class="slider round"></span>
                        </label>
                    </div>
                </div>
                <div class="card" id="sensor-mode-card" style="display: none;">
                    <div class="card-header">
                        <span>Prag Sensor</span>
                    </div>
                    <div class="slider-container">
                        <input type="range" min="1" max="100" value=")" + String(sensorThreshold) + R"(" id="sensor-threshold">
                        <span id="sensor-threshold-value">)" + String(sensorThreshold) + R"(</span>
                    </div>
                </div>
            </div>
        </body>
        </html>
    )";

    server.send(200, "text/html", html);
}

// Handles styles.css

void handleStyles() {
  String css = R"(
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background-color: #f9f9f9;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
}

.container {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    max-width: 1000px;
    margin: 0 auto;
}

.card {
    background: #ffffff;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    padding: 20px;
    text-align: center;
    transition: transform 0.3s;
}

.card:hover {
    transform: translateY(-5px);
}

.card-header {
    display: flex;
    justify-content: center;
    margin-bottom: 20px;
    font-weight: bold;
    font-size: 1.2em;
}

.gauge {
    font-size: 2.5em;
    margin-top: 20px;
}

.slider-container {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 1.2em;
}

input[type="range"] {
    -webkit-appearance: none;
    width: 70%;
    margin-right: 10px;
    background: transparent;
}

input[type="range"]::-webkit-slider-runnable-track {
    width: 100%;
    height: 8.4px;
    cursor: pointer;
    animate: 0.2s;
    background: #417a5f;
    border-radius: 5px;
}

input[type="range"]::-webkit-slider-thumb {
    border: 1px solid #417a5f;
    height: 20px;
    width: 20px;
    border-radius: 50%;
    background: #ffffff;
    cursor: pointer;
    -webkit-appearance: none;
    margin-top: -6px;
}

input[type="range"]:focus::-webkit-slider-runnable-track {
    background: #417a5f;
}

input[type="range"]::-moz-range-track {
    width: 100%;
    height: 8.4px;
    cursor: pointer;
    animate: 0.2s;
    background: #417a5f;
    border-radius: 1.3px;
}

input[type="range"]::-moz-range-thumb {
    border: 1px solid #417a5f;
    height: 20px;
    width: 20px;
    border-radius: 50%;
    background: #ffffff;
    cursor: pointer;
}

input[type="range"]::-ms-track {
    width: 100%;
    height: 8.4px;
    cursor: pointer;
    animate: 0.2s;
    background: transparent;
    border-color: transparent;
    color: transparent;
}

input[type="range"]::-ms-fill-lower {
    background: #417a5f;
    border-radius: 2.6px;
}

input[type="range"]::-ms-fill-upper {
    background: #417a5f;
    border-radius: 2.6px;
}

input[type="range"]::-ms-thumb {
    border: 1px solid #417a5f;
    height: 20px;
    width: 20px;
    border-radius: 50%;
    background: #ffffff;
    cursor: pointer;
}

input[type="range"]:focus::-ms-fill-lower {
    background: #417a5f;
}

input[type="range"]:focus::-ms-fill-upper {
    background: #417a5f;
}

.dropdown-container {
    display: flex;
    justify-content: center;
    align-items: center;
}

select {
    width: 100%;
    padding: 10px;
    font-size: 1em;
    border-radius: 5px;
    border: 1px solid #ccc;
    transition: border-color 0.3s;
}

select:focus {
    border-color: #007bff;
}

.toggle-container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 20px;
}

.switch {
    position: relative;
    display: inline-block;
    width: 60px;
    height: 34px;
}

.switch input {
    display: none;
}

.slider.round {
    border-radius: 34px;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: 0.4s;
    border-radius: 34px;
}

.slider:before {
    position: absolute;
    content: "";
    height: 26px;
    width: 26px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: 0.4s;
    border-radius: 50%;
}

input:checked + .slider {
    background-color: #417a5f;
}

input:checked + .slider:before {
    transform: translateX(26px);
}


  )";
  server.send(200, "text/css", css);
}

// Handles scripts.js
void handleScripts() {
  String js = R"(
document.addEventListener('DOMContentLoaded', function() {
    var workTimeSlider = document.getElementById('work-time');
    var workTimeValue = document.getElementById('work-time-value');
    var restTimeSlider = document.getElementById('rest-time');
    var restTimeValue = document.getElementById('rest-time-value');
    var modeDropdown = document.getElementById('mode');
    var manualModeCard = document.getElementById('manual-mode-card');
    var manualToggle = document.getElementById('manual-toggle');
    var sensorModeCard = document.getElementById('sensor-mode-card');
    var sensorThresholdSlider = document.getElementById('sensor-threshold');
    var sensorThresholdValue = document.getElementById('sensor-threshold-value');

    workTimeSlider.oninput = function() {
        workTimeValue.textContent = this.value;
    };

    restTimeSlider.oninput = function() {
        restTimeValue.textContent = this.value;
    };

    sensorThresholdSlider.oninput = function() {
        sensorThresholdValue.textContent = this.value;
    };

    modeDropdown.onchange = function() {
        var mode = this.value;
        manualModeCard.style.display = mode === '2' ? 'block' : 'none';
        sensorModeCard.style.display = mode === '3' ? 'block' : 'none';
    };

    var sendData = function() {
        var workTime = workTimeSlider.value;
        var restTime = restTimeSlider.value;
        var mode = modeDropdown.value;
        var manualToggleValue = manualToggle.checked ? '1' : '0';
        var sensorThreshold = sensorThresholdSlider.value;

        var xhr = new XMLHttpRequest();
        xhr.open('POST', '/data', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function() {
            if (this.readyState === XMLHttpRequest.DONE && this.status === 200) {
                console.log('Data sent to Arduino');
            }
        };
        xhr.send(`workTime=${workTime}&restTime=${restTime}&mode=${mode}&manualToggle=${manualToggleValue}&sensorThreshold=${sensorThreshold}`);
    };

    workTimeSlider.addEventListener('change', sendData);
    restTimeSlider.addEventListener('change', sendData);
    modeDropdown.addEventListener('change', sendData);
    manualToggle.addEventListener('change', sendData);
    sensorThresholdSlider.addEventListener('change', sendData);
});
  )";
  server.send(200, "application/javascript", js);
}

// Handles 404
void handleNotFound() {
  server.send(404, "text/plain", "404: Not found");
}
